package jep485_Stream_Gatherers;

import static java.io.IO.println;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.util.stream.Gatherer;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class TripleGathererExample {
    void main()
    {
        var result = Stream.of("This", "is", "a", "test").
                gather(triple()).
                toList();
        println(result);

        var result2 = Stream.of(1, 2, 3, 4, 5).
                gather(triple()).
                toList();
        println(result2);
    }


    <T> Gatherer<T, Object, T> triple()
    {
        return new Gatherer<>()
        {
            @Override
            public Integrator<Object, T, T> integrator()
            {
                return new Integrator<>()
                {
                    @Override
                    public boolean integrate(Object unusedState, T element,
                                             Downstream<? super T> downstream)
                    {
                        downstream.push(element);
                        downstream.push(element);
                        downstream.push(element);

                        return true;
                    }
                };
            }
        };
    }


    <T> Gatherer<T, AtomicInteger, T> every2ndTriple()
    {
        return new Gatherer<>()
        {
            @Override
            public Supplier<AtomicInteger> initializer()
            {
                return () -> new AtomicInteger(0);
            }
            @Override
            public Integrator<AtomicInteger, T, T> integrator()
            {
                return new Integrator<>()
                {
                    @Override
                    public boolean integrate(AtomicInteger state, T element,
                                             Downstream<? super T> downstream)
                    {
                        if (state.getAndIncrement() % 2 == 0)
                        {
                            downstream.push(element);
                            downstream.push(element);
                            downstream.push(element);
                        }
                        return true;
                    }
                };
            }
        };
    }

    <T> Gatherer<T, AtomicInteger, T> every2ndTripleAgain()
    {
        return Gatherer.ofSequential(
                AtomicInteger::new,
                (state, element, downstream) ->
                {
                    if (state.getAndIncrement() % 2 == 0)
                    {
                        downstream.push(element);
                        downstream.push(element);
                        downstream.push(element);
                    }
                    return true;
                },
                Gatherer.defaultFinisher()
        );
    }
}
