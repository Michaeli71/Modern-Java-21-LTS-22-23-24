package jep484_Class_File_Api.bonus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.classfile.ClassElement;
import java.lang.classfile.ClassFile;
import java.lang.classfile.ClassModel;
import java.lang.classfile.MethodModel;
import java.nio.file.Path;

/*
Nehmen wir an, wir wollen aus dem Bytecode, also der Klassendatei, alle Methoden entfernen,
die mit dem Startkürzel \code{debug} gekennzeichnet sind. Alles andere soll unverändert bleiben.
Basierend auf den Bytes der Klassendatei wird ein \code{ClassModel} erzeugt. Dieses können
wir über die Methode \code{build()} wird ein \code{ClassBuilder} erzeugt und
es erfolgt die Angabe einer Transformationsvorschrift für die vorzunehmenden Modifikationen.
Dazu durchläuft man alle Elemente vom Typ \code{ClassElement} des \code{ClassModel} und
prüft auf Debug-Methoden und gibt alles andere an den \code{ClassBuilder} weiter:

Aber Achtung: Es werden nur die Methodendefinitionen entfernt, potenzielle Aufrufe nicht!
 */
/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class TransformerDebugRemove {
    public static void main(String[] args) throws IOException {

        ClassFile cf = ClassFile.of();
        ClassModel classModel = cf.parse(Path.of("target/classes/jep457_Class_File_Api/bonus/ExampleDebug.class"));
        byte[] newBytes = cf.build(classModel.thisClass().asSymbol(),
                classBuilder -> {
                    for (ClassElement ce : classModel) {

                        // Step 1:
                        if (!isDebugMethod(ce)) {
                            classBuilder.with(ce);
                        }

                        // Step 2: Problem das ist bestandteil vom CodeModel
                        /*
                        if (!isDebugMethodInvocation(ce)) {
                            classBuilder.with(ce);
                        }
                        */
                    }
                });

        // write without debug methode
        new File("jep457_Class_File_Api_Modified").mkdir();
        try (var fos = new FileOutputStream("jep457_Class_File_Api_Modified/ExampleDebug.class")) {
            fos.write(newBytes);
        }
    }

    private static boolean isDebugMethod(ClassElement ce) {
        return ce instanceof MethodModel methodModel &&
                methodModel.methodName().stringValue().startsWith("debug");
    }

    /*private static boolean isDebugMethodInvocation(ClassElement ce) {
        return ce instanceof InvokeInstruction ii && ii.method().name().stringValue().startsWith("debug");
    }
     */
}
