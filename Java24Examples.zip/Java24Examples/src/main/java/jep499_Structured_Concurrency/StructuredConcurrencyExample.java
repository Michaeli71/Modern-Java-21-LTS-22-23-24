package jep499_Structured_Concurrency;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.*;

import static java.util.concurrent.TimeUnit.NANOSECONDS;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class StructuredConcurrencyExample
{
    public static void main(final String[] args) throws Exception {
        System.out.println(measureExecution(
                           () -> "sync: " + handleSynchronously(4711L)) + " ms");
        System.out.println(measureExecution(
                           () -> "old style: " + handleOldStyle(4711L)) + " ms");
        System.out.println(measureExecution(
                           () -> "new style: " + handle(4711L)) + " ms");
    }

    static long measureExecution(Callable<String> action) throws Exception
    {
        final long startTime = System.nanoTime();
        String result = action.call();
        final long endTime = System.nanoTime();
        System.out.println(result);

        return TimeUnit.MILLISECONDS.convert(endTime - startTime, NANOSECONDS);
    }

        static Response handleSynchronously(final Long userId) throws InterruptedException
        {
            var user = findUser(userId);
            var order = fetchOrder(userId);

            return new Response(user, order);
        }

        static Response handleOldStyle(Long userId) throws ExecutionException,
                                                            InterruptedException
        {
            try(var exectuorService = Executors.newCachedThreadPool())
            {
                var userFuture = exectuorService.submit(() -> findUser(userId));
                var orderFuture = exectuorService.submit(() -> fetchOrder(userId));

                var user = userFuture.get();   // Join findUser
                var order = orderFuture.get();  // Join fetchOrder

                return new Response(user, order);
            }
        }

    static Response handle(Long userId) throws ExecutionException, InterruptedException
    {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            StructuredTaskScope.Subtask<String> userSubtask  = scope.fork(() -> findUser(userId));
            StructuredTaskScope.Subtask<Integer> orderSubtask = scope.fork(() -> fetchOrder(userId));

            scope.join();          // Join both forks
            scope.throwIfFailed(); // ... and propagate errors

            // Here, both forks have succeeded, so compose their results
            return new Response(userSubtask.get(), orderSubtask.get());
        }
    }

    static Response handleWithTimeout(Long userId, Duration timeOut) throws ExecutionException, InterruptedException, TimeoutException {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
            var userSubtask  = scope.fork(() -> findUser(userId));
            var orderSubtask  = scope.fork(() -> fetchOrder(userId));

            scope.joinUntil(Instant.now().plus(timeOut));
            scope.throwIfFailed(); // ... and propagate errors

            // Here, both forks have succeeded, so compose their results
            return new Response(userSubtask .get(), orderSubtask.get());
        }
    }

    static String findUser(Long userId) throws InterruptedException {
        Thread.sleep(2_000);
        return "Michael";
    }

    static Integer fetchOrder(Long userId) throws InterruptedException {
        Thread.sleep(3_000);
        return 42;
    }
    record Response(String userName, Integer orderNo) { }
}