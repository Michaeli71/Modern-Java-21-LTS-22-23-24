package jep487_Scoped_Values.advanced_example;

import java.io.IOException;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class Java23ImprovementsExample
{
    public static void main(String[] args)
    {
        var user = new User("Tim", "Bötz");

        // Java 23: Spezifisches Exception Handling möglich
        try
        {
            var result = ScopedValue.where(ScopedValuesExample.LOGGED_IN_USER, user).
                                     call(() -> Java23ImprovementsExample.performCalculation());
            System.out.println("Calculated result: " + result);
            throw new IOException();
        }
        catch (IOException ioe)
        {
            handleIoException(ioe);
        }

        var result = ScopedValue.where(ScopedValuesExample.LOGGED_IN_USER, user).
                                 call(() -> Java23ImprovementsExample.performCalculationUnchecked());
        System.out.println("Calculated result: " + result);
    }

    static String performCalculation() throws IOException
    {
        if (ScopedValuesExample.LOGGED_IN_USER.isBound())
            return ScopedValuesExample.LOGGED_IN_USER.get().name();

        return "FALLBACK FIRST";
    }

    static String performCalculationUnchecked() throws IllegalStateException
    {
        if (ScopedValuesExample.LOGGED_IN_USER.isBound())
            return ScopedValuesExample.LOGGED_IN_USER.get().nickName();

        return "FALLBACK SECOND";
    }

    private static void handleIoException(IOException ioe)
    {
    }
}
